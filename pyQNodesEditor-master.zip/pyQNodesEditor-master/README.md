pyQNodesEditor
==============

Python port of ALGOholic's QNodesEditor
See ALGOholic for more information:
http://algoholic.eu/qnodeseditor-qt-nodesports-based-data-processing-flow-editor/

This port uses Python3 PySide
Note: Saving/Loading is currently not implemented
